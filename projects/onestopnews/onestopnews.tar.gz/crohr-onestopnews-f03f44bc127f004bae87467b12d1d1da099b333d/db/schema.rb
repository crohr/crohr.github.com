# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of ActiveRecord to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 9) do

  create_table "categories", :force => true do |t|
    t.string "ref"
    t.string "name"
  end

  add_index "categories", ["ref"], :name => "index_categories_on_ref"

  create_table "clusters", :force => true do |t|
    t.decimal  "score",             :precision => 5, :scale => 2
    t.integer  "doc_count",                                       :default => 0
    t.integer  "img_count",                                       :default => 0
    t.integer  "vid_count",                                       :default => 0
    t.integer  "subclusters_count",                               :default => 0
    t.datetime "updated_on"
  end

  add_index "clusters", ["score"], :name => "index_clusters_on_score"
  add_index "clusters", ["updated_on"], :name => "index_clusters_on_updated_on"

  create_table "descriptors", :force => true do |t|
    t.integer "facet_id",                   :null => false
    t.integer "resource_id",                :null => false
    t.integer "stem_id",                    :null => false
    t.integer "frequency",   :default => 0, :null => false
  end

  add_index "descriptors", ["facet_id"], :name => "index_descriptors_on_facet_id"
  add_index "descriptors", ["resource_id"], :name => "index_descriptors_on_resource_id"
  add_index "descriptors", ["stem_id"], :name => "index_descriptors_on_stem_id"

  create_table "facets", :force => true do |t|
    t.string  "ref",    :limit => 50,  :default => "",    :null => false
    t.string  "name",   :limit => 150, :default => "",    :null => false
    t.boolean "active",                :default => false
  end

  create_table "resources", :force => true do |t|
    t.integer  "source_id",                                                :null => false
    t.integer  "subcluster_id"
    t.string   "type",                                  :default => "",    :null => false
    t.string   "title",                                 :default => "",    :null => false
    t.text     "description",                           :default => "",    :null => false
    t.string   "url",                                   :default => "",    :null => false
    t.string   "thumbnail_url"
    t.datetime "published_at"
    t.string   "author",                  :limit => 60
    t.datetime "fetched_at",                                               :null => false
    t.boolean  "indexed",                               :default => false
    t.boolean  "extracted",                             :default => false
    t.boolean  "clustered",                             :default => false
    t.boolean  "thumbnailed",                           :default => false
    t.integer  "classification_accuracy"
  end

  add_index "resources", ["source_id"], :name => "index_resources_on_source_id"
  add_index "resources", ["subcluster_id"], :name => "index_resources_on_subcluster_id"
  add_index "resources", ["published_at"], :name => "index_resources_on_published_at"
  add_index "resources", ["fetched_at"], :name => "index_resources_on_fetched_at"
  add_index "resources", ["indexed"], :name => "index_resources_on_indexed"
  add_index "resources", ["extracted"], :name => "index_resources_on_extracted"
  add_index "resources", ["clustered"], :name => "index_resources_on_clustered"

  create_table "sources", :force => true do |t|
    t.string   "title"
    t.string   "url"
    t.boolean  "active",                    :default => true
    t.integer  "authority",                 :default => 0
    t.string   "type",        :limit => 50
    t.integer  "category_id"
    t.integer  "failures",                    :default => 0
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "sources", ["active"], :name => "index_sources_on_active"
  add_index "sources", ["authority"], :name => "index_sources_on_authority"
  add_index "sources", ["category_id"], :name => "index_sources_on_category_id"
  add_index "sources", ["updated_at"], :name => "index_sources_on_updated_at"

  create_table "stems", :force => true do |t|
    t.string  "name",                               :default => "", :null => false
    t.decimal "idf",  :precision => 8, :scale => 5
  end

  add_index "stems", ["name"], :name => "index_stems_on_name"

  create_table "subclusters", :force => true do |t|
    t.integer  "cluster_id",                                                              :null => false
    t.integer  "doc_count",                                                :default => 0
    t.integer  "img_count",                                                :default => 0
    t.integer  "vid_count",                                                :default => 0
    t.decimal  "score",                      :precision => 5, :scale => 2
    t.string   "main_title"
    t.text     "main_description"
    t.string   "main_thumbnail_url"
    t.datetime "most_recent_published_date"
    t.datetime "created_on"
    t.datetime "updated_on"
  end

  add_index "subclusters", ["cluster_id"], :name => "index_subclusters_on_cluster_id"
  add_index "subclusters", ["created_on"], :name => "index_subclusters_on_created_on"
  add_index "subclusters", ["updated_on"], :name => "index_subclusters_on_updated_on"
  add_index "subclusters", ["score"], :name => "index_subclusters_on_score"

  create_table "terms", :force => true do |t|
    t.integer "stem_id"
    t.string  "name",    :default => "",    :null => false
    t.boolean "default", :default => false
  end

  add_index "terms", ["stem_id"], :name => "index_terms_on_stem_id"
  add_index "terms", ["name"], :name => "index_terms_on_name"

end
