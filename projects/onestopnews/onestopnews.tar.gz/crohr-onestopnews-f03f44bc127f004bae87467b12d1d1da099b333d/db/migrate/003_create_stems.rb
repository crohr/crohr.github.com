class CreateStems < ActiveRecord::Migration
  def self.up
    create_table :stems, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci' do |t|
      t.string :name, :null => false
			t.decimal :idf, :precision => 8, :scale => 5
    end
    add_index :stems, :name
  end

  def self.down
    drop_table :stems
  end
end
