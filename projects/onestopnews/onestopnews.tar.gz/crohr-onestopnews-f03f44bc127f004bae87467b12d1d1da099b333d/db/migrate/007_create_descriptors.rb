class CreateDescriptors < ActiveRecord::Migration
  def self.up
    create_table (:descriptors, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci') do |t|
      t.integer :facet_id				, :null => false
      t.integer :resource_id		, :null => false
      t.integer :stem_id				, :null => false
      t.integer :frequency			, :null => false, :default => 0
    end
		add_index :descriptors, :facet_id
		add_index :descriptors, :resource_id
		add_index :descriptors, :stem_id
  end

  def self.down
    drop_table :descriptors
  end
end
