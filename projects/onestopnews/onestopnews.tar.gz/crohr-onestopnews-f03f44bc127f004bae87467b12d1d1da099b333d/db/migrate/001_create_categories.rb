class CreateCategories < ActiveRecord::Migration
  def self.up
    create_table :categories, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci' do |t|
      t.string :ref
      t.string :name
    end
    add_index :categories, :ref
  end

  def self.down
    drop_table :categories
  end
end
