class CreateFacets < ActiveRecord::Migration
	
  def self.up
    create_table(:facets, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci') do |t|
      t.string :ref, 		:limit => 50, :null => false
      t.string :name, 	:limit => 150, :null => false
			t.boolean :active, :default => false
    end
  end

  def self.down
    drop_table :facets
  end
end
