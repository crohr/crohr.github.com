class CreateSubclusters < ActiveRecord::Migration
  def self.up
    create_table :subclusters, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci' do |t|
			t.integer 	:cluster_id, :null => false
			t.integer		:doc_count, :default => 0
			t.integer	 	:img_count, :default => 0
			t.integer 	:vid_count, :default => 0
			t.decimal 	:score, :precision => 5, :scale => 2
			t.string 		:main_title
			t.text 			:main_description
			t.string 		:main_thumbnail_url
			t.datetime 	:most_recent_published_date
			t.datetime 	:created_on
			t.datetime 	:updated_on
    end
		add_index :subclusters, :cluster_id
		add_index :subclusters, :created_on
		add_index :subclusters, :updated_on
		add_index :subclusters, :score
  end

  def self.down
    drop_table :subclusters
  end
end
