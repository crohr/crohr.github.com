class CreateTerms < ActiveRecord::Migration
  def self.up
    create_table :terms, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci' do |t|
      t.integer :stem_id
      t.string :name, :null => false
			t.boolean :default, :default => false
    end
    add_index :terms, :stem_id
    add_index :terms, :name
  end

  def self.down
    drop_table :terms
  end
end
