class CreateClusters < ActiveRecord::Migration
  def self.up
    create_table :clusters, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci' do |t|
			t.decimal :score, :precision => 5, :scale => 2
			t.integer :doc_count, :default => 0
			t.integer :img_count, :default => 0
			t.integer :vid_count, :default => 0
			t.integer :subclusters_count, :default => 0
			t.datetime :updated_on
    end
		add_index :clusters, :score
		add_index :clusters, :updated_on
  end

  def self.down
    drop_table :clusters
  end
end
