class CreateSources < ActiveRecord::Migration
  def self.up
    create_table :sources, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci' do |t|
      t.string :title
      t.string :url
      t.boolean :active, :default => true
      t.integer :authority, :default => 0
      t.string :type, :limit => 50
			t.integer :category_id
			t.integer :failures, :default => 0
      t.datetime :created_at
      t.datetime :updated_at
    end
    add_index :sources, :active
    add_index :sources, :authority
    add_index :sources, :category_id
    add_index :sources, :updated_at
  end

  def self.down
    drop_table :sources
  end
end
