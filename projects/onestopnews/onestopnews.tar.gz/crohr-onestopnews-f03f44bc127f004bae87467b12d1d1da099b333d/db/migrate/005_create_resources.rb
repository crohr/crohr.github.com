class CreateResources < ActiveRecord::Migration

  def self.up		
    create_table(:resources, :options => 'ENGINE MyISAM COLLATE utf8_unicode_ci') do |t|
      t.integer 	:source_id, 								:null => false
      t.integer 	:subcluster_id, 									:null => true
			t.string		:type, 											:null => false
      t.string 		:title, 										:null => false
      t.text 			:description, 							:null => false
      t.string 		:url, 											:null => false, :uniq => true
      t.string 		:thumbnail_url, 						:null => true
      t.datetime 	:published_at
      t.string 		:author, 										:limit => 60
      t.datetime 	:fetched_at, 								:null => false
      t.boolean 	:indexed, 									:default => false
      t.boolean 	:extracted, 								:default => false
      t.boolean 	:clustered, 								:default => false
      t.boolean 	:thumbnailed, 							:default => false
      t.integer 	:classification_accuracy, 	:null => true

    end
		add_index :resources, :source_id
		add_index :resources, :subcluster_id
		add_index :resources, :published_at
		add_index :resources, :fetched_at
		add_index :resources, :indexed
		add_index :resources, :extracted
		add_index :resources, :clustered
  end

  def self.down
    drop_table :resources
  end
end
