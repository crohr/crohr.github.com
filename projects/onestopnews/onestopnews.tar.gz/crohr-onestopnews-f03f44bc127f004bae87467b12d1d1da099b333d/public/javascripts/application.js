// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults

fire_event_on_event_detail = function(link) {
	if (link.hasClass("selected") || link.hasClass("progress")) {
		link.removeClass('selected');
		link.parent().next().slideUp("slow", function() { $(this).remove(); });
	}	else {
		link.addClass('progress');
		$.get(link.attr('href'), function(data) {
			link.parent().after('<div class="event_details" style="display:none"></div>')
			event_details = link.parent().next();
			event_details.html(data).slideDown(800);
			$('.jcarousel-horizontal', event_details).jcarousel({ 
				scroll: 1
			});
			$('.jcarousel-vertical', event_details).jcarousel({
				vertical: true
		  });
			$.scrollTo(link, 1000, {axis: 'y', offset: -5});	
			link.addClass('selected');
			link.removeClass('progress');
		});
	}
};

filter = function(link) {
	current_stem_id = link.attr('ref');
	if (current_stem_id == 'all') {
			// unselect ALL tags
			$("#clouds .cloud a.selected").removeClass('selected');
			// remove ALL links in filters
			$("#filters ul li a").parent().remove();
			stem_ids = [];			
	} else {
		if (link.hasClass('selected')) {
			// unselect ALL tags having the same ref
			$("#clouds .cloud a[ref='"+current_stem_id+"']").removeClass('selected');
			// remove link in filters
			$("#filters ul li a[ref='"+current_stem_id+"']").parent().remove();
		}	else {
			// select ALL tags having the same ref
			$("#clouds .cloud a[ref='"+current_stem_id+"']").addClass('selected');
			// add link in filter
			$("#filters ul").append('<li><a href="/events/filter/?stems[]='+current_stem_id+'" ref="'+current_stem_id+'" class="filter selected">'+link.html()+'</a></li>');
			// get all selected filters
			stem_ids = jQuery.makeArray( $('#clouds .cloud a.selected').map( function() {
				return $(this).attr('ref');
			} ) );
		}
	}		
	
	$('#events').fadeTo('slow', 0.2, function() {
		$('#main').addClass('spinner');
		// make ajax call
		$.ajax({
			url: '/events/filter',
			cache: false,
			dataType: 'html',
			data: { 
				starts_at: $.getURLParam('starts_at'), 
				ends_at: $.getURLParam('ends_at'), 
				'stems[]': stem_ids
			},
			success: function(data) {
				$('#events').html(data);
				$('#events').fadeTo('slow', 1, function() {
					$('#main').removeClass('spinner');
				});
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				alert("Server seems to be gone. Please try again later.");
				$('#events').fadeTo('slow', 1, function() {
					$('#main').removeClass('spinner');
				});
			}			
		}); // end ajax
	}); // end fadeTo
};


$(document).ready(function() {

	$('body').click(function(event) {
		target = $(event.target);
		// link to see more about each event
		if (target.is("a.more")) {
			fire_event_on_event_detail(target);
			return false;
		}
		// link in filters
		if ( target.is("a.tag") || target.is("a.filter") ) {
			filter(target);
			return false;
		}
		if ( target.is("h1.date") ) {
			target.next().slideToggle('slow', function() {
				$.scrollTo(target, 1000, {axis: 'y', offset: -5});					
			});		
			return false;
		}
 	});



	$('#cloud_picker select').change(function(event) {
		var facet_ref = $("#cloud_picker select option:selected").attr('value');
		$('#clouds .cloud').hide(); 
		if (facet_ref != '-') { 
			var cloud = $('#'+facet_ref+'_cloud');
			$('#reset_filters').removeClass('selected');
			if (!cloud.hasClass('loaded')) {
				$('#clouds .progress').show();
				$.get('/facets/show/'+facet_ref, {starts_at: $.getURLParam('starts_at'), ends_at: $.getURLParam('ends_at'), score: $.getURLParam('score')}, function(data) { 
					cloud.html(data).addClass('loaded'); 
					$('#clouds .progress').hide();
				});
			}
			cloud.show();
		}			
	});
});