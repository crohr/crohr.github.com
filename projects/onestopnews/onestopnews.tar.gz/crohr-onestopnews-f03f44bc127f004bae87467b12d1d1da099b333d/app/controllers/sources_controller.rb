class SourcesController < ApplicationController

	def index
		@sources = Source.find(:all, :order => 'title ASC')
	end
	
	def show
		@source = Source.find params[:id]
	end
	
	def new
		@categories = Category.find(:all, :order => 'name ASC')
		case params[:type]
		when "newsfeed"
			@source = NewsFeed.new
		when "videofeed"
			@source = VideoFeed.new
		when "imagefeed"
			@source = ImageFeed.new
		end
	end
	
	def create
		@categories = Category.find(:all, :order => 'name ASC')
		@source = Source.new(params[:source])
		@source.type = params[:source][:type]
		if @source.save
			flash[:notice] = "Source ajoutée"
			redirect_to sources_path
		else
			flash[:notice] = "Erreur"
			render :action => 'new'
		end
	end
	
	def edit
		@categories = Category.find(:all, :order => 'name ASC')
		@source = Source.find(params[:id])
	end
	
	def update
		@categories = Category.find(:all, :order => 'name ASC')
		@source = Source.find(params[:id])
    if @source.update_attributes(params[:source])
			flash[:notice] = "Source modifiée"
			redirect_to sources_path
		else
			flash[:notice] = "Erreur"
			render :action => 'edit'
		end
	end
	
	def destroy
		@source = Source.find(params[:id])
		@source.destroy
		redirect_to sources_path
	end
end