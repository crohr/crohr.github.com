# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  helper :all # include all helpers, all the time

  # See ActionController::RequestForgeryProtection for details
  # Uncomment the :secret if you're not using the cookie session store
  protect_from_forgery # :secret => '79c8bddbb4c9a3ffcf75a6ad91669e5e'
  
	protected
	def process_events_params
		requires_redirection = false
		# deal with starting date
		if params[:starts_at].blank?
			requires_redirection = true
			@starts_at = Time.now.beginning_of_day.utc
		else 
			@starts_at = Time.at(params[:starts_at].to_i)	
		end			
		# deal with end date
		if params[:ends_at].blank?
			@ends_at = Time.now.end_of_day.utc
			requires_redirection = true
		else	
			@ends_at = Time.at(params[:ends_at].to_i).utc
		end
		# redirects if one of the dates was blank
		if requires_redirection
			redirect_to events_path(:starts_at => @starts_at.to_i, :ends_at => @ends_at.to_i)
			return false
		else
			begin
				@min_score = params[:score].to_f
			rescue
				@min_score = 1.6
			end
			return true
		end
	end 
end
