class StatsController < ApplicationController
	
	def index
		query = %{
			SELECT DATE(published_at) AS date, type, count(*) AS resources_count, sum(clustered) AS clustered_count, sum(extracted) AS extracted_count, sum(indexed) AS indexed_count, sum(thumbnailed) AS thumbnailed_count, count(DISTINCT subcluster_id) AS subclusters_count, count(subcluster_id) AS total_subclusters_count FROM resources GROUP BY date, type ORDER BY date DESC
		}
		@stats = ActiveRecord::Base.connection.select_all("#{query}\n")
	end
	
end