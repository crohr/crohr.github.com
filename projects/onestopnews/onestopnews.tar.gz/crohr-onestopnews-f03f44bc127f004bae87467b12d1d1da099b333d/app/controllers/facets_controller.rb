class FacetsController < ApplicationController
	before_filter :process_events_params, :only => :show
	def index
		@facets = Facet.find(:all, :order => 'ref ASC')
	end
	
	# display the tag cloud associated to this facet
	def show
		@facet = Facet.find_by_ref params[:id]
    events = Subcluster.find_by_interval(@starts_at, @ends_at, :min_score => @min_score)
		render :partial => '/stats/cloud', :object => Cloud.new(events.collect(&:id)).generate(@facet.ref)
	end
	
	def edit
		@facet = Facet.find(params[:id])
	end
	
	def update
		@facet = Facet.find(params[:id])
    if @facet.update_attributes(params[:facet])
			flash[:notice] = "Facet modified"
			redirect_to facets_path
		else
			flash[:notice] = "Error"
			render :action => 'edit'
		end
	end
	
	def destroy
		@facet = Facet.find(params[:id])
		@facet.destroy
		redirect_to facets_path
	end
end