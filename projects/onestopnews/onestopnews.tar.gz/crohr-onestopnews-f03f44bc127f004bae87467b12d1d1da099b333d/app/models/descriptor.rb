class Descriptor < ActiveRecord::Base
	belongs_to :resource
	belongs_to :facet
	belongs_to :stem
end