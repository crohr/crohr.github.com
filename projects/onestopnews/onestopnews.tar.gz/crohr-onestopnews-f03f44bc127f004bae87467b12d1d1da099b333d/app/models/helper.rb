class Helper
	class << self
		def sql_in(array)
			array.collect{|t| "'#{t}'"}.join(", ")
		end
		
		def assert
		  raise "Assertion failed !" unless yield# if $DEBUG
		end

	end
	
end