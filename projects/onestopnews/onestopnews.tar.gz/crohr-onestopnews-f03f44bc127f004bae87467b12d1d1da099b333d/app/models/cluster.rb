class Cluster < ActiveRecord::Base
	has_many :subclusters, :dependent => :destroy
	
	def add(resource_ids)
		resources_by_date = Resource.find(resource_ids).group_by{|r| r.published_at.beginning_of_day}
		resources_by_date.each do |date, resources|
			subcluster = self.subclusters.find(:first, :conditions => ['DATE(most_recent_published_date)=DATE(?)', date])
			if subcluster.nil?
				subcluster = self.subclusters.create
			end
			subcluster.add(resources)
		end
		update_stats!
	end
	
	def remove(resource_ids)
		resources_by_subcluster = Resource.find(resource_ids).group_by(&:subcluster_id)
		resources_by_subcluster.each do |subcluster_id, resources|
			Subcluster.find(subcluster_id).remove(resources)
		end
		update_stats!
		if self.doc_count < 1
			self.destroy
			return :discarded
		else
			return :ok
		end
	end
	
	def update_stats!
		self.score = 0
		self.doc_count = 0
		self.vid_count = 0
		self.img_count = 0
		self.subclusters.each do |subcluster|
			self.doc_count += subcluster.doc_count
			self.vid_count += subcluster.vid_count
			self.img_count += subcluster.img_count
			self.score += subcluster.score
		end
		save!
	end
end
