class Facet < ActiveRecord::Base
	@@facets = nil
	has_many :descriptors, :dependent => :delete_all
	
	validates_presence_of :name, :ref
	validates_uniqueness_of :name, :ref
	
	class << self
		def [](ref)
			@@facets ||= Facet.find(:all).index_by(&:ref)
			unless @@facets.has_key? ref.to_s
				@@facets[ref.to_s] = Facet.create!(:name => ref.to_s.camelcase, :ref => ref.to_s)
			end			
			@@facets[ref.to_s]
		end
	end
end