
class NewsFeed < Source
	
	def store(attributes = {})
		Document.new(attributes)
	end
	
end