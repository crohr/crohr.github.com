class VideoFeed < Source
	
	def store(attributes = {})
		Video.new(attributes)
	end
	
end