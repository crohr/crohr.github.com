class Image < Resource
	protected
	def preprocessing
		img_urls = description.parse_image_urls
		unless img_urls.empty?
			thumbnail_url = img_urls.first
		end
		true
	end
end