require 'feed-normalizer'
require 'open-uri'
class Source < ActiveRecord::Base
	has_many :resources, :dependent => :delete_all
	belongs_to :category
	validates_presence_of :title, :url, :authority
	
	def fetch
		stories = []
		stored_resources = []
	  feed = FeedNormalizer::FeedNormalizer.parse open(url.strip)
	  stories.push(*feed.entries)
		last_fetched_at = self.updated_at || 10000.days.ago
		stories.each do |item|
			next if item.date_published.blank? || item.date_published.utc < last_fetched_at
			stored_resources << store_story(item)
		end
		update_attribute(:updated_at, Time.now.utc)
		stored_resources.compact
	end
	
	  # retrieves the feeds not updated since a certain time
	  def self.not_updated_since(time = 20.minute)
	    self.find_all_by_active(true, :conditions => ['updated_at <= ?',  time.ago(Time.now.utc)])
	end
	
	protected
	def store_story(item)		
		object = store(:title => item.title, :url => item.url, :fetched_at => Time.now.utc, :published_at => item.date_published.utc, :description => item.description, :source_id => self.id, :author => item.author)
		if object.save
			unless self.category.nil?
				object.add_descriptor(Facet['category'], Indexing::Stemmer.stem(self.category.name.downcase), [self.category.name])
				object.update_attribute(:classification_accuracy, 1)
			end
			object
		else
			nil
		end
	end
	
end