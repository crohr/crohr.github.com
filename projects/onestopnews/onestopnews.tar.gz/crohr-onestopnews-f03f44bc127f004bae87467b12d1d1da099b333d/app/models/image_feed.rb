
class ImageFeed < Source
	
end