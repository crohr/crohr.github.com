class Stem < ActiveRecord::Base
	has_many :terms, :dependent => :delete_all, :order => 'terms.default DESC'
	has_many :descriptors
	validates_uniqueness_of :name
	
	def self.update_idf		
		nb_of_resources = Resource.count
		query = %{
			SELECT stem_id, LOG(#{nb_of_resources}/count(distinct resource_id)) AS idf from descriptors group by stem_id
		}
		results = ActiveRecord::Base.connection.select_all("#{query}\n")
		results.each do |r|
			Stem.find(r['stem_id']).update_attribute(:idf, r['idf'].to_f)			
		end
	end
end