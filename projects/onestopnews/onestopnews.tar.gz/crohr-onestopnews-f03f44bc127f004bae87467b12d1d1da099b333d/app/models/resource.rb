require 'calais'

class Resource < ActiveRecord::Base
	belongs_to :subcluster
	belongs_to :source
	has_many :descriptors, :dependent => :delete_all
	  
  validates_presence_of :source_id, :url, :title, :description, :fetched_at, :published_at
	validates_length_of :description, :minimum => 100
	validates_length_of :title, :minimum => 20
	validates_format_of :url, :with => /(^$)|(^(http|https):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(([0-9]{1,5})?\/.*)?$)/ix


  before_validation :preprocessing, :clean_attributes
	before_create 		:check_uniqueness
	
	def sparse_vector
		@sparse_vector ||= descriptors.inject({}){|memo, d| memo[d.stem_id] = d.frequency; memo}
	end
	
	
	def index
    stem_tokens = tokenize(description).group_by do |term| 
      Indexing::Stemmer.stem term
    end.each do |stem, terms|
			self.add_descriptor(Facet['word'], stem, terms)
		end
		update_attribute(:indexed, true)
	end
	
	def add_descriptor(facet, stem_name, term_names)
		stem = Stem.find_by_name(stem_name.downcase)
		if stem.nil?
			stem = Stem.create(:name => stem_name.downcase)
		end
		term_names.each do |term_name|
			# default = (facet.ref != 'word')
			default = false
			if facet.ref != 'word' || stem.terms.length == 0
				default = true
			end
			stem.terms << Term.new(:name => term_name.downcase, :default => default)
		end
		self.descriptors << Descriptor.new(:facet_id => facet.id, :stem_id => stem.id, :frequency => term_names.length)
	end
	
	
	def extract_entities
		key = 'yw8zeypm93v2bs8wh647cw6m'
		begin
			calais = Calais.process_document(:content => description, :content_type => :text, :license_id => key)
			update_attribute(:extracted, true)
			calais.names.each do |name|
				# note: we don't aggregate the frequency: if 2 identical names are present, there will be 2 tuples.
				facet = Facet[name.type.underscore]
				term_name = name.name
				stem_name = Indexing::Stemmer.stem term_name
				add_descriptor(facet, stem_name, [term_name])
			end
		rescue => exception
			logger.warn "-> Error when extracting entities from Resource##{id}:\n#{exception}"
		end
	end
	
	def extract_image
		img = nil
		begin
			uri = URI::parse(url)
			text = Fetching.fetch(url).read
			images = Fetching::Multimedia.extract_images(text, uri)
			unless images.empty?
				img = images.first
				update_attribute(:thumbnail_url, img)
				Fetching.store(img, File.join(RAILS_ROOT, 'public', path_to_thumb), "#{id}")
			end
		rescue => exception
			logger.error "Error when fetching #{url} from resource #{id}: #{exception}"
		ensure
			# we don't want to spend to much time trying again and again to thumbnail a resource.
			# if it fails, that's it.
			update_attribute(:thumbnailed, true)
		end
		img
  end
	
	def self.to_be_clustered(options = {})
		#####
		# condition on published_at IS ABSOLUTELY REQUIRED  
		# in order to avoid clustering bias due to resources with a published date in the future
		#####
		options = {:limit => 200, :order => 'published_at ASC'}.merge(options)
		self.find_all_by_clustered(false, :conditions => ['published_at <= ? AND indexed = ? AND extracted = ?', Time.now.utc, true, true], :limit => options[:limit], :order => options[:order])
	end
	
	def thumbnail(size = 'cropped')
		if thumbnailed && !thumbnail_url.nil?
			"/"+path_to_thumb+"/#{id}_#{size}.jpg"
		else
			nil
		end
	end
	
	protected
	# to be surcharged in the descendants
	def preprocessing
		true
	end
  def clean_attributes
		self.title ||= ""
		self.description ||= ""

    self.description = self.description.strip_html_tags.strip_useless_whitespaces
    self.title = self.title.strip_html_tags.strip_useless_whitespaces
    self.title = self.title.gsub(/\s-\s.*/, '')
		# UTC time
    self.published_at = self.published_at.utc unless self.published_at.nil?
		true
  end

	def check_uniqueness
		if Resource.count(:id, :conditions => ["url = ? OR (source_id = ? AND title = ?)", url, source_id, title]) > 0
			errors.add_to_base("This resource is already in the database")
			false
		else
			true
		end
	end
	
	def path_to_thumb
		path = File.join('illustrations', *("%08d" % id).scan(/..../))
	end
	
	def tokenize(text)
		 Indexing::Tokenizer.parse(text.downcase).strip_punctuation.split(" ").reject{|w| w.length <= 2}-Indexing.stopwords
	end
end