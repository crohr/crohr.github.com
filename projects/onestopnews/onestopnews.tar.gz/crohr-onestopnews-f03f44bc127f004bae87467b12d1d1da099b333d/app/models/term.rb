class Term < ActiveRecord::Base
	belongs_to :stem
	validates_uniqueness_of :name
end