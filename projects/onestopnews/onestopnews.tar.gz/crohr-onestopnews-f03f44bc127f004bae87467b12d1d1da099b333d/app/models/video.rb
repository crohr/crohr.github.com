class Video < Resource
	
	protected
	def preprocessing
		img_urls = description.parse_image_urls
		unless img_urls.empty?
			self.thumbnail_url = img_urls.first
		end
		true
	end
	
end