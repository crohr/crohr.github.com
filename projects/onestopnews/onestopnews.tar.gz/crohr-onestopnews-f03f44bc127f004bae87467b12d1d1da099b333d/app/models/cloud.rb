
class Cloud
	def initialize(subcluster_ids)
		@subcluster_ids = subcluster_ids
		raise ArgumentError, "Expects an array of subcluster ids." unless @subcluster_ids.kind_of? Array
	end
	
	def generate(facet, options = {})
		return [] if @subcluster_ids.empty?
		options.symbolize_keys!
		options = {:limit => 10}.merge(options)
		if Facet[facet].nil?
			raise ArgumentError, "The facet #{facet} doesn't exist."
		end
		query = generate_query_for_facet(facet, options)
		cloud = ActiveRecord::Base.connection.select_all("#{query}\n")
		cloud.collect do |hash|
			Tag.new(hash['tag_id'].to_i, facet, hash['label'], hash['value'].to_f)
		end.sort{|a, b| a.name <=> b.name}
	end
	
	protected
		
	# do not forget to set the default field for the terms!
	def generate_query_for_facet(facet, options)
		query = %{
			SELECT terms.name AS label, terms.stem_id AS tag_id, stems.idf*count(DISTINCT resources.id) AS value
			FROM descriptors
			INNER JOIN resources ON resources.id = descriptors.resource_id
			INNER JOIN subclusters ON subclusters.id = resources.subcluster_id AND subclusters.id IN (#{Helper.sql_in(@subcluster_ids)})
			INNER JOIN facets ON facets.id = descriptors.facet_id AND facets.ref = '#{facet}'
			INNER JOIN stems ON stems.id = descriptors.stem_id
			INNER JOIN terms ON terms.stem_id = stems.id AND terms.default = 1
			GROUP BY stems.id ORDER BY value DESC LIMIT 0,#{options[:limit]}
		}# AND terms.default = 1
	end
	
	class Tag
		attr_accessor :id, :name, :count, :type
		def initialize(id, type, name, count)
			@id = id
			@type = type
			@name = name
			@count = count
		end
	
		def hash
			[type, name].join("_").downcase.gsub(/\W/, '_').squeeze('_')
		end
	end
end
