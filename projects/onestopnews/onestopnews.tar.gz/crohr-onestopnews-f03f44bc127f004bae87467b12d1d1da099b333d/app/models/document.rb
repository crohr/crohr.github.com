class Document < Resource

end