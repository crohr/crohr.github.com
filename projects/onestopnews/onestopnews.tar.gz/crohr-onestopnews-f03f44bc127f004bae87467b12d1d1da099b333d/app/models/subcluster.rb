class Subcluster < ActiveRecord::Base
	has_many :images, :order => 'resources.published_at DESC', :dependent => :nullify
	has_many :videos, :order => 'resources.published_at DESC', :dependent => :nullify
	has_many :documents, :order => 'resources.published_at DESC', :dependent => :nullify
	has_many :resources, :order => 'resources.published_at DESC', :dependent => :nullify
	has_one :main_resource, :class_name => 'Resource', :order => 'resources.published_at DESC', :dependent => :nullify
	belongs_to :cluster, :counter_cache => true
		
	def add(new_resources)
		new_resources.each do |resource|
			case resource.class.to_s
			when "Document"
				self.doc_count+=1
			when "Image"
				self.img_count+=1
			when "Video"
				self.vid_count+=1
			end
			self.resources << resource
		end
		update_stats!
	end
	
	def remove(old_resources)
		old_resources.each do |resource|
			case resource.class.to_s
			when "Document"
				self.doc_count-=1
			when "Image"
				self.img_count-=1
			when "Video"
				self.vid_count-=1
			end
			self.resources.delete resource
		end
		update_stats!
		if self.doc_count < 1
			self.destroy
		end
	end
	
	def update_stats!
		self.score = compute_score
		unless self.score == 0
			self.most_recent_published_date = self.resources.last.published_at
		end
		save!
	end
	
	# returns the number of articles per day on a sliding window of 30 days around the published date
	def timeline(starting_date = nil)
		starting_date ||= most_recent_published_date
		range = (5.days.ago(starting_date).to_date..([(Time.now.utc-starting_date)/1.day, 5].min).days.since(starting_date).to_date)
		logger.info range.to_a.inspect
		query = %{
			SELECT DATE(most_recent_published_date) AS label, SUM(doc_count)+SUM(vid_count)+SUM(img_count) AS value FROM subclusters 
			WHERE cluster_id = '#{self.cluster_id}'
			GROUP BY id ORDER BY most_recent_published_date ASC
		}
		final_timeline = range.to_a.inject({}){ |memo, date| memo[date.to_date] = 0; memo }
		logger.info final_timeline.inspect
		result = Subcluster.connection.select_all("#{query}\n")
		result.each do |r| 
			label = Time.parse(r['label']).to_date
			if final_timeline.has_key? label
				final_timeline[label] = r['value']
			end
		end
		final_timeline.sort{|a, b| a[0] <=> b[0] }.collect{ |(label, value)| {'label' => label.strftime("%d %b"), 'value' => value.to_i} }
	end
	
	def illustrations
		@illustrations ||= self.resources.collect(&:thumbnail).compact
	end
	
	def main_illustration
		if illustrations.empty?
			nil
		else
			illustrations.last
		end
	end
	
	def categories
		query = %{
			SELECT terms.name AS category FROM terms
			INNER JOIN stems ON stems.id = terms.stem_id
			INNER JOIN descriptors ON descriptors.stem_id = stems.id AND descriptors.facet_id = '#{Facet['category'].id}'
			INNER JOIN resources ON resources.id = descriptors.resource_id AND resources.subcluster_id = '#{self.id}'
			ORDER BY category ASC
		}
		result = Subcluster.connection.select_all("#{query}\n")
		result.collect{|r| r['category'].capitalize}.uniq
	end
	
	# fetch the subclusters corresponding to options
	# the "date" entry must be of 2 elements length (start, end)
	# the "stems" entry consists in a list of stem id
	def self.filter_by(options)
		default_options = {:date => [], :stems => [], :min_score => 1.6}
		options = default_options.merge(options)
		assert options[:stems].is_a?(Array), \
							"You must pass an array of stems"
		assert options[:date].is_a?(Array) \
							&& options[:date].length == 2 \
							&& options[:date].first.kind_of?(Time) \
							&& options[:date].last.kind_of?(Time) , \
							"You must pass an array containing 2 dates"
		logger.info "OPTIONS="+options.inspect
		if options[:stems].empty?
			Subcluster.find_by_interval(options[:date].first, options[:date].last, :min_score => options[:min_score].to_f)
		else
			query = %{
				SELECT subclusters.id FROM subclusters
				INNER JOIN resources ON resources.subcluster_id = subclusters.id
				INNER JOIN descriptors ON descriptors.resource_id = resources.id
				INNER JOIN stems ON stems.id = descriptors.stem_id AND stems.id IN (#{Helper.sql_in(options[:stems])})
				WHERE subclusters.most_recent_published_date BETWEEN '#{options[:date].first.to_s(:db)}' AND '#{options[:date].last.to_s(:db)}' AND score >= '#{options[:min_score].to_f}'
			}
			result = Subcluster.connection.select_all("#{query}\n")
			Subcluster.find(result.collect{|r| r['id'].to_i}, :order => 'score DESC')	
		end	
	end
	
	def self.find_by_interval(starts_at, ends_at, options = {})
		default_options = {:min_score => 1.6, :order => 'score DESC'}
		options = default_options.merge(options)
		Subcluster.find(:all, :conditions => ['most_recent_published_date > ? AND most_recent_published_date < ? AND score > ?', starts_at, ends_at, options[:min_score].to_f], :order => options[:order])
	end
	
	def compute_score
		Math.log(self.doc_count+self.img_count+self.vid_count+1)
	end
	
end