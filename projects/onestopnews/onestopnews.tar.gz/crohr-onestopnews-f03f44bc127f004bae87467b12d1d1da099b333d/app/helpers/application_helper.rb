# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
	def tag_cloud(tags, classes)
    return if tags.empty?
    
    max_count = tags.sort_by(&:count).last.count.to_f
    
    tags.each do |tag|
      index = ((tag.count / max_count) * (classes.size - 1)).round
      yield tag, classes[index]
    end
		return
  end


	
	def short_text(text, number_of_words = 20)
		new_text = text.split(/\s/)[0..number_of_words].join(" ")
		if new_text.length < text.length
			new_text+="..."
		end
		new_text
	end
	
	def date_ago(seconds = 0.days)
	 	seconds.ago.beginning_of_day.utc.to_i#strftime("%Y-%m-%d %H:%M")
	end
	def date_since(seconds = 0.days)
	 	seconds.since.end_of_day.utc.to_i#strftime("%Y-%m-%d %H:%M")
	end
	
end
