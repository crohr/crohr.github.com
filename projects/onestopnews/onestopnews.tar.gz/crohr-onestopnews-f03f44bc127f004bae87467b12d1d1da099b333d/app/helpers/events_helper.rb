module EventsHelper
	def display_thumbnail(thumb, title = '')
		if thumb.nil?
			image_tag('unknown.png', :alt => title, :size => '100x100')
		else
			image_tag(thumb, :alt => title, :size => '100x100')
		end		
	end
end
