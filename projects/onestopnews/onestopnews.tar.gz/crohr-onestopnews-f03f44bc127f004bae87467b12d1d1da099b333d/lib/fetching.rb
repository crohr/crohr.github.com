require 'rubygems'
require 'open-uri'
require 'timeout'
require 'image_science'
require 'fileutils'
require 'hpricot'

require File.dirname(__FILE__) + "/fetching/multimedia"
require File.dirname(__FILE__) + "/fetching/parser"

class String
	include Fetching::Parser
end

module Fetching
	def fetch(url)
	 	Timeout::timeout(25) do
			page = open(url.strip)
		end
	rescue Timeout::Error
		raise "Timeout when fetching #{url}"
	end
	
	# assume that the file to store has an extension
	def store(url, path, filename, options = {})
		file = nil
		result = nil
		file = Fetching.fetch(url)
		file_filename = url.split("/")[-1]
		file_extension = file_filename.split(".")[-1]
  	# ensure the directory exists...
  	FileUtils.mkdir_p(path)
		result = path+"/#{filename}"
		File.open(result+"."+file_extension, 'w') do |f|
			f.write file.read
		end
		ImageScience.with_image(result+"."+file_extension) do |img|
      img.cropped_thumbnail(100) do |thumb|
        thumb.save "#{result}_cropped.jpg"
      end
      img.thumbnail(100) do |thumb|
        thumb.save "#{result}_thumb.jpg"
      end
      # img.resize(100, 150) do |img2|
      #   img2.save "#{result}_resize.png"
      # end
    end
		result
	end
	
	module_function :fetch, :store
end

