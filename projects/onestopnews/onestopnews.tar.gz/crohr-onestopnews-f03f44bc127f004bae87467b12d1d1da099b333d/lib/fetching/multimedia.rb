

module Fetching

  class Multimedia
	
		def self.extract_images(text, uri = nil)
			Hpricot.buffer_size = 2621444
			good_regexps = [ 	Regexp.new(/image/i), 
									Regexp.new(/photo/i), 
									Regexp.new(/caption/i),
									Regexp.new(/related/i),
									Regexp.new(/img/i) ]
			bad_regexps = [  Regexp.new(/marketing/i), Regexp.new(/promo/i), Regexp.new(/latest news/i) ]
			images = []
			#Rdoc: http://code.whytheluckystiff.net/hpricot/
			doc = Hpricot(text)
			doc.search("img").each do |img|		
				img_score = 0.0						
				mix = [img['id'], img['class']].compact
				mix.each do |attribute|
					good_regexps.each do |regexp|
						img_score += 1 if attribute =~ regexp
					end
				end
				[mix, img['src']].compact.each do |attribute|
					bad_regexps.each do |regexp|
						img_score -= 100 if attribute =~ regexp
					end
				end		
				# advantage for images with ALT tags
				img_score += 2 if img['alt'] && img['alt'].length > 20
				# advantage for large images
				img_score += 1 if img['width'] && img['width'].to_i > 220
				img_score += 1 if img['height'] && img['height'].to_i > 170
				images << [img['src'], img_score]
			end
			
			[doc.search("div").uniq, doc.search("a").uniq].flatten.compact.each do |div|
				inner_text = div.inner_html.strip_html_tags.strip_useless_whitespaces
				div_score = 0.0
				mix = [div['id'], div['class']].compact
				mix.each do |attribute|
					good_regexps.each do |regexp|
						div_score += 2 if attribute =~ regexp
					end
				end
				[mix, inner_text].compact.each do |attribute|
					bad_regexps.each do |regexp|
						div_score -= 100 if attribute =~ regexp
					end
				end
				if div_score > 0
					# length of the text within the DIV
					div_length = inner_text.length
					# collect the IMG tags
					img_elements = div.search("img").uniq
					img_elements.each do |img|
						img_score = div_score						
						mix = [img['id'], img['class']].compact
						mix.each do |attribute|
							good_regexps.each do |regexp|
								img_score += 5 if attribute =~ regexp
							end
						end
						[mix, img['src']].compact.each do |attribute|
							bad_regexps.each do |regexp|
								img_score -= 100 if attribute =~ regexp
							end
						end
						# disadvantage if the image comes from a slideshow or something like that.
						# most of the time it's related stories, etc.
						img_score -= (img_elements.length)
						# disadvantage if the div only contains an image but not text (caption, etc.)
						div_length < 10 ? img_score -= 1 : img_score += 1
						# advantage for images with ALT tags
						img_score += 5 if img['alt'] && img['alt'].length > 15
						# advantage for large images
						img_score += 1 if img['width'] && img['width'].to_i > 300
						img_score += 1 if img['height'] && img['height'].to_i > 200
						images << [img['src'], img_score]
					end
				end
			end
			# reject negative scores, gif images, and sort by score DESC
			result = images.reject{|i| i[1] <= 2 || i[0] =~ /\.gif/i}.sort{|a, b| b[1] <=> a[1]}.uniq.collect do |i|
				uri.nil? ? i[0] : uri.merge(i[0]).to_s
			end
			result
		end
	
		
		def self.retrieve_video_for(object)
      client = YouTubeG::Client.new
      videos = []
      if object.respond_to? 'title'
        v = client.videos_by(:query => object.title)
        if v.total_result_count > 0
          videos << v.videos
        end
      end
      # TODO parametres pour choisir quelle type de recherche on veut
      if object.respond_to? 'frequent_stems'
        v = client.videos_by(:tags => object.frequent_stems(:limit => 2).keys.collect{|stem| stem.terms.first.name})
        if v.total_result_count > 0
          videos << v.videos
        end
      end
      videos.flatten
    end
  end
  
end # fetching

