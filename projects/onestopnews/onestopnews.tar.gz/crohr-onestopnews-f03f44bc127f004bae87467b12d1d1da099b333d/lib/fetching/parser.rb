module Fetching
# Parser
module Parser
	# look for IMG tags in the string and returns an array with their urls
	def parse_image_urls
		dup = self.clone
		image_urls = []
		while dup.length > 0
			m = /<img.*?src=(.*?\.(jpg|jpeg|gif|bmp|png))[?|'|"|>|\/>|\s].*?/iu.match(dup)
			# m = /<img.*?src=(.*?)[?|'|"|>|\/>|\s].*?/iu.match(dup)
			if m.nil? || m[1].nil?
				break
			else
				image_urls << m[1].strip_quotes
				dup = m.post_match
			end
		end
		return image_urls
	end
	
	# erase single quote or double quote from the string
	def strip_quotes
		self.gsub(/"|'/, '')
	end
	
	# remove all non word signs from the phrase
	def strip_punctuation
		self.gsub(/\W/, ' ')
	end
	
	# strip HTML tags from the string and replace each fragment with a space
	# (except at the beginning and at the end of the string)
	def strip_html_tags
		[" ", self.gsub(/<(.|\n)*?>/, ' ').gsub(/<!\[CDATA\[/, ' ').gsub(/\]\]>/, ' '), " "].join("").squeeze(' ')[1..-2]
	end
	
	# check if the string is a good url
	def url?
		if self[0..6] =~ /http:\/\//i
			true
		else
			false
		end
	end
	
	# remove \n, \t, \r and multiple whitespaces
	def strip_useless_whitespaces
		[' ', self.gsub(/\n|\t|\r/, ' '), ' '].join('').squeeze(' ')[1..-2]
	end
end
end