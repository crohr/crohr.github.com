class ImagesWorker < BackgrounDRb::MetaWorker
  set_worker_name :images_worker
	# set_no_auto_load true
  def create(args = nil)
    # this method is called, when worker is loaded for the first time    
		# in seconds
    add_periodic_timer(25.minutes) { extract_images }
		register_status(Time.now.utc)
  end

	def extract_images
		resources = Resource.find_all_by_thumbnailed(false, :order => 'published_at ASC', :limit => 200)
		logger.info "[image extraction] #{resources.length} resources to process."
		resources.each do |resource|
			begin
				resource.extract_image
			rescue => exception
				logger.error "[image extraction] ---> Error for #{resource.title}:\n#{exception.backtrace}"
				next
			end
		end
		logger.info "[image extraction] image extraction done at #{Time.now.utc.to_s(:db)}."
		register_status(Time.now.utc)
	end
	
end

