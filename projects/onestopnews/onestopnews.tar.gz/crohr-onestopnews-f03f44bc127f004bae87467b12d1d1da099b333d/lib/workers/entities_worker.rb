class EntitiesWorker < BackgrounDRb::MetaWorker
  set_worker_name :entities_worker
	# set_no_auto_load true
	# set_no_auto_load true
  def create(args = nil)
    # this method is called, when worker is loaded for the first time
		# in seconds
    add_periodic_timer(25.minutes) { extract_entities }
		register_status(Time.now.utc)
  end

	def extract_entities
		resources = Resource.find_all_by_extracted(false, :limit => 100, :order => 'published_at ASC')
		logger.info "[entity extraction] #{resources.length} resources for which to extract entities."
		resources.each do |resource|
			begin
				resource.extract_entities
			rescue => exception
				logger.error "[entity extraction] ---> Error for #{resource.title}:\n#{exception.backtrace}"
			end
		end
		logger.info "[entity extraction] entity extraction done."
		register_status(Time.now.utc)
	end
	
end

