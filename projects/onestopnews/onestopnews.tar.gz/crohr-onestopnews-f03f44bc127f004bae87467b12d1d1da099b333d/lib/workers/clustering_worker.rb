require 'madeleine'
require 'clustering'
class ClusteringWorker < BackgrounDRb::MetaWorker
  set_worker_name :clustering_worker
	# set_no_auto_load true
  def create(args = nil)
    # this method is called, when worker is loaded for the first time
		# in seconds
		add_periodic_timer(20.minutes) { cluster }
		register_status(Time.now.utc)
  end
	
	
	def cluster
		logger.info "[clustering] starting at #{Time.now.utc.to_s(:db)}."
		logger.info "[clustering] updating idf..."
		Stem.update_idf
		logger.info "[clustering] idf updated."
		path_to_persistence = RAILS_ROOT+"/common/clustering"
		snapshots = Dir[path_to_persistence+"/*.snapshot"].sort
		logger.info "[clustering] #{snapshots.length} snapshots."
		if snapshots.length > 10
			logger.info "[clustering] deleting snapshots..."
			snapshots[0..-2].each do |file|
			File.delete(file)
			end
			logger.info "[clustering] snapshots deleted."
		end
		stems = Stem.find(:all).collect{|s| Clustering::Feature.new(s.id, s.idf)}.index_by(&:id)
		logger.info "[clustering] #{stems.length} stems."

		Clustering::Repository.resources = Resource#resources
		Clustering::Repository.stems = stems
		Clustering::Repository.similarity_matrix = Clustering::SparseTriangularMatrix.new
		Clustering::Histogram.number_of_bins = 100
		Clustering::Histogram.similarity_threshold = 0.3 # close to 1 = we want almost exact same articles
		options = {:hr_min => 0.6, :epsilon => 0.3, :checkpoint_at => 10, :weak_threshold => 0.1, :min_resources => 4, :time_window => 10.days, :flag_threshold => 10}

		starts_at = Time.now.to_i


		persistance_layer = SnapshotMadeleine.new(path_to_persistence) {
			Clustering::ClusteringJob.new([])
		}


		resources = Resource.to_be_clustered(:limit => 400).collect{|r| Clustering::Item.new(r.id, r.published_at.to_i, r.class.to_s, r.sparse_vector)}
		logger.info "[clustering] #{resources.length} resources to cluster."
		
		resources.each do |item|
			persistance_layer.system.resources.push(item)
		end
		
		persistance_layer.system.run(options) do 
						|clusters, discarded_clusters, resources_clustered_since_last_checkpoint| 
			logger.info "Checkpoint on the client side..."
			logger.info clusters.first.histogram.inspect
			# destroy discarded clusters
			Cluster.find(discarded_clusters).each{|c| logger.info "Destroying #{c.id}.."; c.destroy}
			# update or create clusters
			create_themes(clusters, 5)
			Resource.update_all("clustered = 1", ['id IN (?)', resources_clustered_since_last_checkpoint.collect(&:id)])
			persistance_layer.take_snapshot
		end
		logger.info "[clustering] clustering done at #{Time.now.utc.to_s(:db)}."
		register_status(Time.now.utc)
	end
	

	def create_themes(clusters, min_resources = 3)
		clusters.each do |cluster|
			if cluster.updated
				cluster.updated = false
				if cluster.db_id
					# fetch the cluster in DB
					master = Cluster.find(cluster.db_id)
					query = %{
						SELECT resources.id, resources.subcluster_id FROM resources
						INNER JOIN subclusters ON subclusters.id = resources.subcluster_id
						INNER JOIN clusters ON clusters.id = '#{cluster.db_id}' AND clusters.id = subclusters.cluster_id
					}
					# get the resources already attached to this cluster
					db_resources = ActiveRecord::Base.connection.select_all("#{query}\n")
					db_resources = db_resources.map{|r| r['id'].to_i}
					cluster_resources = cluster.resources.collect{|r| r.id.to_i}
					# collect and save the resources which are new and need to be saved
					resources_to_save = cluster_resources - db_resources
					master.add(resources_to_save)
					# collect and delete the resources which are no longer in the cluster
					resources_no_longer_here = db_resources - cluster_resources
					result = master.remove(resources_no_longer_here)
					if result == :discarded
						cluster.db_id = nil
					end
				elsif cluster.resources.length >= min_resources
					# create a new cluster in DB
					master = Cluster.create
					master.add(cluster.resources.collect{|r| r.id.to_i})
					cluster.db_id = master.id
				end
			end #updated?
		end # clusters.each
	end


end

