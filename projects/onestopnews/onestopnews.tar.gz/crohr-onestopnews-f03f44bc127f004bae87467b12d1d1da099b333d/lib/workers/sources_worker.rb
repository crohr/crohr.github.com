class SourcesWorker < BackgrounDRb::MetaWorker
  set_worker_name :sources_worker
	# set_no_auto_load true
  def create(args = nil)
    # this method is called, when worker is loaded for the first time    
		# in seconds
    add_periodic_timer(17.minutes) { update_sources }
		register_status(Time.now.utc)
  end

	def update_sources
		sources = Source.not_updated_since(10.seconds)
		logger.info "[rss] #{sources.length} sources to process."
		sources.each do |source|
			logger.info "[rss] fetching #{source.title}..."
			begin
	  		Timeout::timeout(15) do
					r = source.fetch
					logger.info "[rss] ---> #{r.length} stories."
				end
			rescue Timeout::Error
	  		logger.error "[rss] ---> Timeout for #{source.title}."
				source.increment!(:failures)
			rescue => exception
				logger.error "[rss] ---> Unknown Error for #{source.title}:\n#{exception.backtrace}"
				source.increment!(:failures)
			end
		end
		logger.info "[rss] sources updated at #{Time.now.utc.to_s(:db)}."
		register_status(Time.now.utc)
	end
end

