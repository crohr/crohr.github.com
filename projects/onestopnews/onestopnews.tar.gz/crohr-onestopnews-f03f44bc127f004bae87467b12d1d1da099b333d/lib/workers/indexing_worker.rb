class IndexingWorker < BackgrounDRb::MetaWorker
  set_worker_name :indexing_worker
	# set_no_auto_load true
  def create(args = nil)
    # this method is called, when worker is loaded for the first time
		# in seconds
    add_periodic_timer(20.minutes) { index }		
		register_status(Time.now.utc)
  end

	def index
		resources = Resource.find_all_by_indexed(false, :limit => 200, :order => 'published_at ASC')
		logger.info "[indexing] #{resources.length} resources to index."
		resources.each do |resource|
			begin
				resource.index
			rescue => exception
				logger.error "[indexing] ---> Error for #{resource.title}:\n#{exception.backtrace}"
			end
		end
		logger.info "[indexing] indexing done at #{Time.now.utc.to_s(:db)}."
		register_status(Time.now.utc)
	end
	
end

