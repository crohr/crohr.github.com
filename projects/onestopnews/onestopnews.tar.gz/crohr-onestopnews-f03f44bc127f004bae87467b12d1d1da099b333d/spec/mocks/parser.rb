require 'rubygems'
require 'rubyful_soup'
require 'webfetcher'
require '../../lib/string_parser'
class String
	include StringParser
end
# 
# #Create the soup
# input = File.open('cnn_article.html', 'r').read
# soup = BeautifulSoup.new(input)
# 
# #Search the soup
# titleTag = soup.html.head.title
# puts titleTag
# # words_title = titleTag.string.downcase.split(/\s/)
# # puts words_title
# 
# divs = soup.html.body.find_all('div') { |div| 
# 	div['id'] =~ /image/i || div['id'] =~ /photo/i || div['id'] =~ /caption/i || div['class'] =~ /image/i || div['class'] =~ /photo/i || div['class'] =~ /caption/i
# 	}
# divs.each do |div|
# 	puts "------------ new div"
# 	puts div
# 	#index = input.index(div)
#   #text_to_analyze = input[[index-500, 0].max..[index+500, input.length].min]
# 	images = div.to_s.parse_image_urls
# 	images.each do |img|
# 		puts img
# 	end
# end


# 
# def fetch_url(url)
# 	puts "URL= "+url
#   return nil unless url.url?
# 	text = nil
# 	uri = nil
#     # open-uri RDoc: http://stdlib.rubyonrails.org/libdoc/open-uri/rdoc/index.html
# 	begin
# 		open(url) { |f|
# 			uri = f.base_uri
# 			text = f.read
# 		}
# 	rescue Exception => e
# 		puts "error"+e.to_s
# 		uri = nil
# 		text = nil
# 	end
# 	unless text.nil?
# 		text = text.strip_useless_whitespaces
# 	end
# 	[uri, text]
# end

# url = "http://bits.blogs.nytimes.com/2008/02/01/microsoft-is-building-a-spaceship-out-of-spare-parts/?WT.mc_id=TE-D-I-NYT-MOD-BIG-M031-ROS-0208-L1&WT.mc_ev=click&mkt=TE-D-I-NYT-MOD-BIG-M031-ROS-0208-L1"
# p = WebFetcher::Page.url(url)
# uri = URI::parse(url)
# puts uri.methods.join(" -- ")
# puts uri.merge('http://www.cryx.net/blabla/bla.jpg')
# puts uri.host
# puts uri.path
# puts uri.port
# 
# puts uri.scheme
# puts p.host+":"+p.port.to_s
# puts p.dirname
# 
def clusters(node, tree = {}, results = [])
	used_nodes = [node]
	#puts "NODE = #{node.inspect}"
	tree[node][:leaves].each do |l|
		if l =~ /GENE/
			results.last << l
		end
		if l =~ /NODE/
			used_nodes << clusters(l, tree, results)
		end
	end
	used_nodes
end

tree = {
	"NODE1" => {:leaves => %w(GENE1 NODE2)},
	"NODE2" => {:leaves => %w(GENE3 GENE4)},
	"NODE3" => {:leaves => %w(GENE2 GENE5)},
	"NODE4" => {:leaves => %w(NODE3 NODE1)}
	}
nodes = %w(NODE2 NODE1 NODE3 NODE4)
results = []
nodes.reverse!
# go through the tree and extract the clusters
while not nodes.empty?
	results << []
	used_nodes = clusters(nodes.shift, tree, results).flatten
	#puts "used_nodes = #{used_nodes.inspect}"
	nodes -= used_nodes
end
puts results.inspect



# images = soup.html.body.find_all('img') {|img| img['alt'] and img['alt'].length > 20 and img['src'] =~ /.*\.jpg.*/}
# images.each do |img|
# 	puts img
# 	words_alt = img['alt'].downcase.split(/\s/)
# 	puts words_alt.join(", ")
# 	puts "---"
# 	puts (words_alt & words_title).join(" -- ")
# end