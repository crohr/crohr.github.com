require File.join( File.dirname(__FILE__), "..", "spec_helper" )

describe "A subcluster" do

	describe "has stats which" do
		it "should be updated after adding new resources" do
			resources = [
					mock('resource', :class => Image),
					mock('resource', :class => Video),
					mock('resource', :class => Document),
					mock('resource', :class => Document)
				]
			sub = Subcluster.create(:cluster_id => 1, :vid_count => 2, :img_count => 3, :doc_count => 5)
			sub.resources.stub!(:<<)
			sub.resources.stub!(:last).and_return(mock('resource', :published_at => 1.day.ago.utc))
			sub.add(resources)
			sub.reload
			sub.doc_count.should == 7
			sub.vid_count.should == 3
			sub.img_count.should == 4
			sub.most_recent_published_date.should be_close(1.day.ago.utc, 1.minute)
		end
		
		it "should be updated after removing resources" do
			resources = [
					mock('resource', :class => Image),
					mock('resource', :class => Video),
					mock('resource', :class => Document),
					mock('resource', :class => Document)
				]
			sub = Subcluster.create(:cluster_id => 1, :vid_count => 2, :img_count => 3, :doc_count => 5)
			sub.resources.stub!(:delete)
			sub.resources.stub!(:last).and_return(mock('resource', :published_at => 1.day.ago.utc))
			sub.remove(resources)
			sub.reload
			sub.doc_count.should == 3
			sub.vid_count.should == 1
			sub.img_count.should == 2
			sub.most_recent_published_date.should be_close(1.day.ago.utc, 1.minute)
		end
	end
	
	describe "for which resources are removed" do
	  it "should delete the resources" do
			resources = [
					mock('resource', :class => Image),
					mock('resource', :class => Video),
					mock('resource', :class => Document),
					mock('resource', :class => Document)
				]
			sub = Subcluster.new(:vid_count => 2, :img_count => 3, :doc_count => 5)
			sub.resources.should_receive(:delete).exactly(4).times
			sub.should_receive(:update_stats!)
			sub.should_not_receive(:destroy)
			sub.remove(resources)
		end
		
		it "should decrement its counters" do
			resources = [
					mock('resource', :class => Image),
					mock('resource', :class => Video),
					mock('resource', :class => Document),
					mock('resource', :class => Document)
				]
			sub = Subcluster.new(:vid_count => 2, :img_count => 3, :doc_count => 5)
			sub.resources.stub!(:delete).and_return(true)
			sub.should_receive(:update_stats!)
			sub.remove(resources)
			sub.vid_count.should == 1
			sub.img_count.should == 2
			sub.doc_count.should == 3
		end
		
		it "should be destroyed if it has less than one document" do
			resources = [
					mock('resource', :class => Image),
					mock('resource', :class => Video),
					mock('resource', :class => Document)
				]
			sub = Subcluster.new(:vid_count => 2, :img_count => 3, :doc_count => 1)
			sub.resources.stub!(:delete).and_return(true)
			sub.should_receive(:update_stats!)
			sub.should_receive(:destroy)
			sub.remove(resources)
		end
	end

end