require File.join( File.dirname(__FILE__), "..", "spec_helper" )

describe Facet do

  it "should find existing facet" do
		Facet['category'].should_not be_nil
		Facet['category'].ref.should == 'category'
	end
	
	it "should create non-existing facets on the fly" do
		facet = mock('facet')
		Facet.should_receive(:create!).with(:name => "Fakefacet", :ref => "fakefacet").and_return(facet)
		Facet['fakefacet'].should == facet
	end

end