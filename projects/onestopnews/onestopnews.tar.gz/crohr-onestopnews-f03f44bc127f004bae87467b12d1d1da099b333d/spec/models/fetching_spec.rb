require File.dirname(__FILE__) + '/../spec_helper'

describe Fetching do
	it "should timeout if fetch doesn't return in less than 15 seconds" do
		Fetching.should_receive(:open).and_return {raise Timeout::Error, "Timeout"}
		lambda{Fetching.fetch("http://www.domaine.com")}.should raise_error("Timeout when fetching http://www.domaine.com")
	end
	# it "should detect images in a reuters article" do
	#   images = @extractor.extract_images("http://www.alertnet.org/thenews/newsdesk/L27168799.htm", nil)
	# 	images.first.should == "http://www.alertnet.org/thefacts/imagerepository/RTRPICT/2008-02-27T134409Z_01_EDN21_RTRIDSP_2_QUAKE-BRITAIN_mainimage.jpg"
	# end
	# 
	# 
	# it "should detect images in a reuters nytimes" do
	#   images = @extractor.extract_images("http://www.reuters.com/article/worldNews/idUSL2615008920080226?feedType=RSS&feedName=worldNews", nil)
	# 	images.first.should == "http://www.reuters.com/resources/r/?m=02&d=20080226&t=2&i=3302080&w=192&r=2008-02-26T170618Z_01_L26150089_RTRUKOP_0_PICTURE0"
	# end

	
	it "should detect images in the neighbourhood NYTIMES" do
		url = File.dirname(__FILE__) + '/../mocks/nytimes_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://graphics8.nytimes.com/images/2008/02/12/us/12fisa-600.jpg'
	end
	it "should NOT detect images in the neighbourhood NYTIMES" do
		url = File.dirname(__FILE__) + '/../mocks/nytimes_noimage_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images.should be_empty
	end



	it "should detect images in the neighbourhood CNN" do
		url = File.dirname(__FILE__) + '/../mocks/cnn_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://i.l.cnn.net/cnn/2008/SHOWBIZ/Movies/02/10/bafta.ap/art.lewis.cotillard.getty.jpg'
	end

	it "should detect images in the neighbourhood INDEPENDENT" do
		url = File.dirname(__FILE__) + '/../mocks/independent_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://www.independent.co.uk/multimedia/archive/00015/tv-debate-120208_15920t.jpg'
	end
	
	it "should detect images in the neighbourhood ABC" do
		url = File.dirname(__FILE__) + '/../mocks/abc_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://www.abc.net.au/reslib/200802/r221279_870750.jpg'
	end
	
	it "should detect images in the neighbourhood BOSTON" do
		url = File.dirname(__FILE__) + '/../mocks/boston_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://cache.boston.com/resize/bonzai-fba/AP_Photo/2008/02/12/1202856505_5167/539w.jpg'
	end
	
	it "should detect images in the neighbourhood CBS" do
		url = File.dirname(__FILE__) + '/../mocks/cbs_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://wwwimage.cbsnews.com/images/2008/01/07/image3683090g.jpg'
	end
	
	it "should detect images in the neighbourhood USATODAY" do
		url = File.dirname(__FILE__) + '/../mocks/usatoday_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://i.usatoday.net/news/_photos/2008/02/10/huckabee2x.jpg'
	end
	
	it "should detect images in the neighbourhood YAHOO" do
		url = File.dirname(__FILE__) + '/../mocks/yahoo_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://d.yimg.com/us.yimg.com/p/ap/20080211/capt.92ac120226fe4e5987813703498d51b1.correction_pakistan_violence_mrn101.jpg?x=180&y=129&q=85&sig=gpsoFcsQzIYVUe0_YD.2rQ--'
	end
	
	it "should detect images in the neighbourhood WSJ" do
		url = File.dirname(__FILE__) + '/../mocks/wsj_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://s.wsj.net/public/resources/images/PJ-AL796_BAXTER_20080211202330.jpg'
	end # VERY HARD

	# # at the time, it extracts false-positives, so we better have deactivated it
	# it "should detect images in ALERTNET" do
	# 	url = File.dirname(__FILE__) + '/../mocks/alertnet_article.html'
	# 	text = File.open(url, "r").read
	#   images = @extractor.extract_images(text)
	# 	images.should be_empty
	# 	#[0].should == 'http://graphics8.nytimes.com/images/2008/02/12/us/12fisa-600.jpg'
	#   end
	
	# at the time, it extracts false-positives, so we better have deactivated it
	it "should NOT detect images in REUTERS" do
		url = File.dirname(__FILE__) + '/../mocks/reuters_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images.should be_empty
		# == 'http://www.reuters.com/resources/r/?m=02&d=20080514&t=2&i=4262007&w=192&r=2008-05-14T225802Z_01_N08399567_RTRUKOP_0_PICTURE0'
	end	# at the time, it extracts false-positives, so we better have deactivated it
	
	it "should NOT detect images in LATIMES" do
		url = File.dirname(__FILE__) + '/../mocks/latimes_noimage_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images.should be_empty
	end
	
	it "should NOT detect images in IHT" do
		url = File.dirname(__FILE__) + '/../mocks/iht_noimage_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images.should be_empty
	end
	
	it "should detect images in MSNBC" do
		url = File.dirname(__FILE__) + '/../mocks/msnbc_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == "http://msnbcmedia.msn.com/j/msnbc/Components/Photo_StoryLevel/080529/080529-iraq-hmed-5a.hmedium.jpg"
	end
	
	
	it "should detect images in AP" do
		url = File.dirname(__FILE__) + '/../mocks/ap_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text, URI::parse("http://hosted.ap.org/dynamic/stories/I/IRAQ?SITE=CARIE&SECTION=HOME&TEMPLATE=DEFAULT"))
		images[0].should == 'http://hosted.ap.org/photos/F/ff86f6be-d028-471a-9d2c-7f70a19f7dd1-small.jpg'
	end
	
	it "should detect images in AP 2" do
		url = File.dirname(__FILE__) + '/../mocks/ap2_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text, URI::parse("http://hosted.ap.org/dynamic/stories/T/TEN_FRENCH_OPEN?SITE=WILAC&SECTION=HOME&TEMPLATE=DEFAULT"))
		images[0].should == 'http://hosted.ap.org/photos/5/514eff4c-2ee0-48e5-8aeb-37bb745687d0-small.jpg'
	end
	
	it "should detect images in BBC" do
		url = File.dirname(__FILE__) + '/../mocks/bbc_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://newsimg.bbc.co.uk/media/images/44700000/jpg/_44700298_livni_226afp.jpg'
	end
	
	it "should detect images in BBC 2" do
		url = File.dirname(__FILE__) + '/../mocks/bbc2_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://newsimg.bbc.co.uk/media/images/44697000/jpg/_44697846_maliki_afp_226body.jpg'
	end
	 
	it "should NOT detect images in THE AGE" do
		url = File.dirname(__FILE__) + '/../mocks/theage_noimage_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images.should be_empty
	end
	
	
	it "should detect images in GUARDIAN" do
		url = File.dirname(__FILE__) + '/../mocks/guardian_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images[0].should == 'http://image.guim.co.uk/sys-images/Sport/Pix/pictures/2008/05/29/christophekarabaepa2460276.jpg'
	end
	it "should NOT detect images in GUARDIAN" do
		url = File.dirname(__FILE__) + '/../mocks/guardian_noimage_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images.should be_empty
	end
	
	
	it "should detect images in TIMES" do
		url = File.dirname(__FILE__) + '/../mocks/times_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text, URI::parse("http://www.timesonline.co.uk/tol/news/world/asia/article4022960.ece#cid=OTC-RSS&attr=797093"))
		images[0].should == 'http://www.timesonline.co.uk/multimedia/archive/00345/Celebrate385_345331a.jpg'
	end
	
	it "should NOT detect images in SEATTLEPI" do
		url = File.dirname(__FILE__) + '/../mocks/seattlepi_noimage_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text)
		images.should be_empty
	end
	
	it "should detect images in CLARION LEDGER" do
		url = File.dirname(__FILE__) + '/../mocks/clarionledger_article.html'
		text = File.open(url, "r").read
	  images = Fetching::Multimedia.extract_images(text, URI::parse("http://hosted.ap.org/dynamic/stories/I/IRAQ?SITE=MSJAD&SECTION=HOME&TEMPLATE=DEFAULT"))
		images[0].should == 'http://hosted.ap.org/photos/0/00c63bbc-2447-45b6-bbd3-907c33e68e0b-small.jpg'
	end
end