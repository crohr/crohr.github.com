require File.join( File.dirname(__FILE__), "..", "spec_helper" )
module SourceSpecHelper
	def valid_attributes
		{
			:title => "CNN World",
			:url => "http://us.rd.yahoo.com/dailynews/rss/world/*http://news.yahoo.com/s/ap/20080514/ap_on_re_as/china_earthquake"
		}
	end
end

describe Source do
	include SourceSpecHelper
	it "should be valid" do
		a = Source.new(valid_attributes)
		a.valid?
	end
	
	it "should return stories when fetched" do
		rss_file = File.dirname(__FILE__) + '/../mocks/edition_world.rss'
		source = Source.new(:title => 'CNN World', :url => rss_file, :updated_at => nil)
		source.stub!(:store_story).and_return(mock('resource'))
		stories = source.fetch
		stories.should_not be_empty
	end
	
	it "should not store stories published before its last update" do
		rss_file = File.dirname(__FILE__) + '/../mocks/edition_world.rss'
		source = Source.new(:title => 'CNN World', :url => rss_file, :updated_at => 10.days.since)
		source.stub!(:store_story).and_return(mock('resource'))
		stories = source.fetch
		stories.should be_empty		
	end

end