require File.join( File.dirname(__FILE__), "..", "spec_helper" )

def valid_attributes
	{
		:title => "State media: China quake death nears 15,000 (AP)",
		:description => %{<p><a href="http://us.rd.yahoo.com/dailynews/rss/world/*http://news.yahoo.com/s/ap/20080514/ap_on_re_as/china_earthquake"><img src="http://d.yimg.com/us.yimg.com/p/nm/20080514/2008_05_13t033312_450x335_us_quake.jpg?x=130&y=96&q=85&sig=UGKqJikHSxNv9xDQd.lLdQ--" align="left" height="96" width="130" alt="A soldier holds back relatives trying to enter a collapsed school building, after an earthquake in Dujiangyan City, 50km (31 miles) from Chengdu in Sichuan province May 13, 2008. (Claro Cortes IV/Reuters)" border="0" /></a>AP - The official death toll from a powerful earthquake in central China has risen to almost 15,000.</p><br clear="all"/>},
		:url => "http://us.rd.yahoo.com/dailynews/rss/world/*http://news.yahoo.com/s/ap/20080514/ap_on_re_as/china_earthquake",
		:published_at => 2.day.ago.utc,
		:fetched_at => 2.day.ago.utc,
		:source_id => 1
	}
end

describe Video do
	
	describe "additional validation after processing" do
		before(:each) do
			@video = Video.new(valid_attributes)
		end
		
		it "should not be valid if description length after sanitization is lower than 100" do
			@video.description = %{<p><a href="http://us.rd.yahoo.com/dailynews/rss/world/*http://news.yahoo.com/s/ap/20080514/ap_on_re_as/china_earthquake"><img src="http://d.yimg.com/us.yimg.com/p/nm/20080514/2008_05_13t033312_450x335_us_quake.jpg?x=130&y=96&q=85&sig=UGKqJikHSxNv9xDQd.lLdQ--" align="left" height="96" width="130" alt="A soldier holds back relatives trying to enter a collapsed school building, after an earthquake in Dujiangyan City, 50km (31 miles) from Chengdu in Sichuan province May 13, 2008. (Claro Cortes IV/Reuters)" border="0" /></a>AP - The official death toll from a powerful earthquake in central China has risen to almost 15,000</p><br clear="all"/>} # 99 characters after sanitization
			@video.valid?.should be_false
		end
		it "should not be valid if title length after sanitization is lower than 20" do
			@video.title = "State me <b>China</> (AP)" # 19 characters after sanitization
			@video.valid?.should be_false
		end
		
		it "should have populated the thumbnail_url after validation, if description contains images" do
			@video.valid?
			@video.thumbnail_url.should == "http://d.yimg.com/us.yimg.com/p/nm/20080514/2008_05_13t033312_450x335_us_quake.jpg"
		end
	end

end