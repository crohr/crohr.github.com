require File.join( File.dirname(__FILE__), "..", "spec_helper" )

describe Category do

  it "should have specs"

end