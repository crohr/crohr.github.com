require File.join( File.dirname(__FILE__), "..", "spec_helper" )

module ResourceSpecHelper
	def valid_attributes
		{
			:title => "State media: China quake death nears 15,000 (AP)",
			:description => %{<p><a href="http://us.rd.yahoo.com/dailynews/rss/world/*http://news.yahoo.com/s/ap/20080514/ap_on_re_as/china_earthquake"><img src="http://d.yimg.com/us.yimg.com/p/nm/20080514/2008_05_13t033312_450x335_us_quake.jpg?x=130&y=96&q=85&sig=UGKqJikHSxNv9xDQd.lLdQ--" align="left" height="96" width="130" alt="A soldier holds back relatives trying to enter a collapsed school building, after an earthquake in Dujiangyan City, 50km (31 miles) from Chengdu in Sichuan province May 13, 2008. (Claro Cortes IV/Reuters)" border="0" /></a>AP - The official death toll from a powerful earthquake in central China has risen to almost 15,000.</p><br clear="all"/>},
			:url => "http://us.rd.yahoo.com/dailynews/rss/world/*http://news.yahoo.com/s/ap/20080514/ap_on_re_as/china_earthquake",
			:published_at => 2.day.ago.utc,
			:fetched_at => 2.day.ago.utc,
			:source_id => 1
		}
	end
end

describe Resource do
	include ResourceSpecHelper
	before(:each) do
		# WHY AM I required to do that???
		Resource.delete_all
		Stem.delete_all
		Term.delete_all
		Descriptor.delete_all
	end
	describe "built-in validations" do
		before(:each) do
			@resource = Resource.new(valid_attributes)
			@resource.stub!(:preprocessing).and_return(true)
			@resource.stub!(:clean_attributes).and_return(true)
		end
		it "should pass the built-in validations" do
			@resource.valid?.should be_true
		end
		it "should have a correct url" do
			@resource.url = "us.rd.yahoo.com/dailynews/rss/world/*http://news.yahoo.com/s/ap/20080514/ap_on_re_as/china_earthquake"
			@resource.valid?.should be_false
		end
	end
	
	describe "additional validation after processing" do
		before(:each) do
			Resource.delete_all
			@resource = Resource.new(valid_attributes)
		end
		
		it "should receive calls to additional processing" do
			@resource.should_receive(:preprocessing).and_return(true)
			@resource.should_receive(:clean_attributes).and_return(true)
			@resource.valid?
		end
		
		it "should be valid" do
			@resource.should be_valid
		end
		
		it "should not be valid if description length after sanitization is lower than 100" do
			@resource.description = %{<p><a href="http://us.rd.yahoo.com/dailynews/rss/world/*http://news.yahoo.com/s/ap/20080514/ap_on_re_as/china_earthquake"><img src="http://d.yimg.com/us.yimg.com/p/nm/20080514/2008_05_13t033312_450x335_us_quake.jpg?x=130&y=96&q=85&sig=UGKqJikHSxNv9xDQd.lLdQ--" align="left" height="96" width="130" alt="A soldier holds back relatives trying to enter a collapsed school building, after an earthquake in Dujiangyan City, 50km (31 miles) from Chengdu in Sichuan province May 13, 2008. (Claro Cortes IV/Reuters)" border="0" /></a>AP - The official death toll from a powerful earthquake in central China has risen to almost 15,000</p><br clear="all"/>} # 99 characters after sanitization
			@resource.valid?.should be_false
		end
		
		it "should not be valid if title length after sanitization is lower than 20" do
			@resource.title = "State me <b>China</> (AP)" # 19 characters after sanitization
			@resource.valid?.should be_false
		end
	
		
		it "should be created if valid" do
			lambda {@resource.save!}.should_not raise_error
		end
		
		it "should have been preprocessed once created" do
			@resource.save!
			@resource.description.should == "AP - The official death toll from a powerful earthquake in central China has risen to almost 15,000."
			@resource.title.should == "State media: China quake death nears 15,000 (AP)"
		end
		
		it "should not create a new record if same record already exists in DB" do
			resource_dup = Resource.new(valid_attributes)
			@resource.save!
			lambda{resource_dup.save!}.should raise_error(ActiveRecord::RecordNotSaved)
			resource_dup.errors['base'].should =~ /already in the database/
		end
		
		it "should not create a new record if almost same record (title and source identical) already exists in DB" do
			resource_dup = Resource.new(valid_attributes)
			resource_dup.url = "http://cnn.com/news/1"
			@resource.save!
			lambda{resource_dup.save!}.should raise_error(ActiveRecord::RecordNotSaved)
		end
	end

	describe "custom finders" do
		it "should get all resources ready to be clustered" do
			r1 = Resource.new(valid_attributes.merge(:indexed => false, :extracted => false, :clustered => false))
			r2 = Resource.new(valid_attributes.merge(:indexed => true, :extracted => false, :clustered => false))
			r3 = Resource.new(valid_attributes.merge(:indexed => true, :extracted => true, :clustered => false))
			r4 = Resource.new(valid_attributes.merge(:indexed => true, :extracted => true, :clustered => true))
			[r1, r2, r3, r4].each do |r|
				r.stub!(:preprocessing).and_return(true)
				r.stub!(:clean_attributes).and_return(true)
				r.stub!(:check_uniqueness).and_return(true)
				r.save_with_validation(false).should be_true
			end
			Resource.to_be_clustered.should == [r3]
		end 
	end
	
	describe "descriptors" do
		before(:each) do
			@resource = Resource.create!(valid_attributes)
		end
		it "should add a new descriptor given a term, a facet and a frequency" do
			facet = stub_everything('facet')
			stem = stub_everything('stem')
			Stem.should_receive(:find_by_name).and_return(stem)
			@resource.add_descriptor(facet, "fakeword", 1)
			@resource.should have(1).descriptors
		end
		it "should create a new stem if the stem doesn't exist for a particular term" do
			Indexing::Stemmer.should_receive(:stem).with("fakeword").and_return("fakew")
			facet = stub_everything('facet')
			stem = stub_everything('stem')
			Stem.should_receive(:find_by_name).and_return(nil)
			Stem.should_receive(:create).with(:name => "fakew").and_return(stem)
			@resource.add_descriptor(facet, "FakeWord", 1)
		end
	end
	
	describe "indexing" do
		before(:each) do
			@resource = Resource.create!(valid_attributes)
			String.new.should respond_to(:strip_punctuation)
		end
		
		it "should tokenize the description" do
			string = "a fake description used for test purpose. Tokenizer, punctuation striping etc. should be tested in their own spec."
			@resource.should_receive(:tokenize).with(@resource.description).and_return([])
			@resource.index
		end
		
		it "should add a descriptor for each stem with the correct frequency" do
			string = "a fake description used for test purpose. Tokenizer, punctuation striping etc. should be tested in their own spec."
			facet = mock('facet', :id => 1000)
			Facet.should_receive(:[]).exactly(4).times.with('word').and_return(facet)
			@resource.stub!(:tokenize).and_return(%w(a b c d a b c a b a))
			@resource.should_receive(:add_descriptor).with(facet, "a", 4)
			@resource.should_receive(:add_descriptor).with(facet, "b", 3)
			@resource.should_receive(:add_descriptor).with(facet, "c", 2)
			@resource.should_receive(:add_descriptor).with(facet, "d", 1)
			@resource.index
		end
	end
end