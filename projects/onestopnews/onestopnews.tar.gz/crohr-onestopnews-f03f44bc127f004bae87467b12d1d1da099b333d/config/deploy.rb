
set :runner, :deploy
set :application, "onestopnews"
set :repository,  "http://cryx.unfuddle.com/svn/cryx_onestopnews"
set :scm, "subversion"
set :svn_username, "cryx"
set :svn_password, "16487395"
set :user, "deploy" 

# If you aren't deploying to /u/apps/#{application} on the target
# servers (which is the default), you can specify the actual location
# via the :deploy_to variable:
set :deploy_to, "/var/apps/#{application}"

# If you aren't using Subversion to manage your source code, specify
# your SCM below:
# set :scm, :subversion

role :app, "onestopnews.fit.qut.edu.au"
role :web, "onestopnews.fit.qut.edu.au"
role :db,  "onestopnews.fit.qut.edu.au", :primary => true



task :after_update_code, :roles => :app, :except => {:no_symlink => true} do 
  # (create and) link the feeds directory to the current release
  run <<-CMD
    if [[ ! -d #{shared_path}/common ]]; then mkdir #{shared_path}/common; fi && cd #{release_path} && ln -nfs #{shared_path}/common #{release_path}/common
  CMD
	run <<-CMD
		cd #{release_path} && ln -nfs #{shared_path}/pids #{release_path}/tmp/pids
	CMD
  run <<-CMD
    if [[ ! -d #{shared_path}/common/illustrations ]]; then mkdir #{shared_path}/common/illustrations; fi && cd #{release_path} && ln -nfs #{shared_path}/common/illustrations #{release_path}/public/illustrations
  CMD
  run <<-CMD
    if [[ ! -d #{shared_path}/config ]]; then mkdir #{shared_path}/config; fi
  CMD
end 



namespace :deploy do	
  desc "Restart the backgroundrb processes"
  task :restart_background, :roles => :app do
    stop_background
    start_background
  end

	desc "Start background processes"
	task :start_background, :roles => :app do
    run "cd /var/apps/onestopnews/current && /usr/local/bin/ruby ./script/backgroundrb start -e production"
	end
	
	desc "Stop background processes"
	task :stop_background, :roles => :app do
    run "cd /var/apps/onestopnews/current && /usr/local/bin/ruby ./script/backgroundrb stop -e production"
	end
	
  desc "Restart the cluster"
  task :restart, :roles => :app do
    stop
    start
  end
  
  desc "Start the cluster"
  task :start, :roles => :app do
    start_mongrel
  end
  
  desc "Stop the cluster"
  task :stop, :roles => :app do
    stop_mongrel
  end
  
  desc "Start thin"
  task :start_thin, :roles => :app do
    begin
      run "/etc/init.d/thin start -C /etc/thin/qut_news.yml"
    rescue RuntimeError => e
      puts e
      puts "Thin appears to be down already."
    end
  end
  
  desc "Stop thin"
  task :stop_thin, :roles => :app do
    begin
      run "/etc/init.d/thin stop -C /etc/thin/qut_news.yml"
    rescue RuntimeError => e
      puts e
      puts "Thin appears to be down already."
    end
  end


  desc "Start mongrels"
  task :start_mongrel, :roles => :app do
    begin
			run "/usr/bin/mongrel_rails cluster::start -C /var/apps/onestopnews/shared/config/mongrel_cluster.yml --clean"
    rescue RuntimeError => e
      puts e
      puts "Mongrels appear to be down already."
    end
  end
  desc "Stop mongrels"
  task :stop_mongrel, :roles => :app do
    begin
			run "/usr/bin/mongrel_rails cluster::stop -C /var/apps/onestopnews/shared/config/mongrel_cluster.yml --clean"
    rescue RuntimeError => e
      puts e
      puts "Mongrels appear to be down already."
    end
  end
end